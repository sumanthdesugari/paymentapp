package com.cg.wallet.staticdb;

import java.util.HashMap;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Transaction;

public class StaticDB {
	
	
	static HashMap<Long,Account>acMap =
			 new HashMap<Long,Account>();
	static HashMap<Long,Transaction>tsMap =
			 new HashMap<Long,Transaction>();
	
	
	public static HashMap<Long,Account> getAccount()
	{
		return acMap;
	}
	public static HashMap<Long,Transaction> getTransaction()
	{
		return tsMap;
	}
}
